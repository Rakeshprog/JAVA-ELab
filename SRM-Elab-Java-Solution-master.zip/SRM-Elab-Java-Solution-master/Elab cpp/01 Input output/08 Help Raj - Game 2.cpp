/*Try the following example.

Ramu was given a game by his friend raj. When raj says a number then raj needs to tell that number.

And when Raj says a word or character he has to remain silent. Kindly help Raju and Ramu to solve the task.

Refer the sample input and output
TEST CASE 1

INPUT
43.333
OUTPUT
43.333
TEST CASE 2

INPUT
56.788
OUTPUT
56.788

*/

#include <iostream>
using namespace std;
int main() {
	float no;
  cin>>no;
  cout<<no;
	return 0;
}