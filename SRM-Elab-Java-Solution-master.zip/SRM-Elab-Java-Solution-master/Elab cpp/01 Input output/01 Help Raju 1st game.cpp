/*
Ramu was given a game by his friend raj.

When raj says a number then Ramu needs to tell that number.

Kindly help Raj and Ramu to solve the task.

Refer the sample input and output for example
TEST CASE 1

INPUT
34
OUTPUT
34
TEST CASE 2

INPUT
44
OUTPUT
44
*/
#include <iostream>
using namespace std;
int main ()
{
  int no;
  cin>>no;
  cout<<no;
  return 0;
}


